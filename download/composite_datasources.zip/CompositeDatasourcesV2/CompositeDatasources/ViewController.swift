//
//  ViewController.swift
//  CompositeDatasources
//
//  Created by Thomas Mary on 22/04/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

