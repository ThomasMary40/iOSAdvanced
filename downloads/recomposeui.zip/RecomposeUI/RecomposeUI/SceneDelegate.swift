//
//  SceneDelegate.swift
//  RecomposeUI
//
//  Created by Thomas Mary on 22/04/2022.
//
//  When an event trigger to paid UI, completly change the UI
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {

        guard let windowScene = (scene as? UIWindowScene) else { return }

        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = makeFreeUI()
        window?.makeKeyAndVisible()
    }

    private func makeFreeUI() -> UIViewController {
        let vc = UIViewController()

        vc.view.backgroundColor = .yellow
        vc.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Start subscription", primaryAction: UIAction{[weak self] _ in
            self?.window?.rootViewController = self?.makePaidUI()
        })

        return UINavigationController(rootViewController: vc)
    }

    private func makePaidUI() -> UIViewController {
        let vc = UIViewController()

        vc.view.backgroundColor = .green
        vc.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "End subscription", primaryAction: UIAction{[weak self] _ in
            self?.window?.rootViewController = self?.makeFreeUI()
        })

        return UINavigationController(rootViewController: vc)
    }
}

